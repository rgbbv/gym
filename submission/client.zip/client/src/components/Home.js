import React from 'react'
import Classes from './Classes'


const Home = (props) => {
  return (
    <div>
      <div className="App">
        <header className="My Gym">
          <Classes />
        </header>
      </div>
    </div>
  )
}

export default Home